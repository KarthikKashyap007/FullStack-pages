import React from "react";
import "./signup.css";
// import { Link } from "react-router-dom";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const Signup = () => {

    
    const [register,setRegister]=React.useState({
        name:"",
        email:"",
        password:""
    });

    const navigate= useNavigate();

    const handleChange = (e)=>{
        setRegister({
           ...register,
           [e.target.name]:e.target.value
        })
    }
        
        const handleSubmit=async (e)=>{
            e.preventDefault();
            console.log(register);
            try{
                const response= await  axios.post("http://localhost:8080/addUser", register);
                console.log(response.data);
                alert("User added successfully");
                navigate("/Login");
            }
            catch(error)
            {
                console.log(error);
            }

        }
   

  return (
    <div className="addUser">
       
      <h3>Sign Up</h3>
      <form className="addUserForm" onSubmit={handleSubmit}>
        <div className="inputGroup">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            autoComplete="off"
            placeholder="Enter your name"
            value={register.name}
            onChange={handleChange}
          />
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            autoComplete="off"
            placeholder="Enter your Email"
            value={register.email}
            onChange={handleChange}
          />
          <label htmlFor="Password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            autoComplete="off"
            placeholder="Enter Password"
            value={register.password}
            onChange={handleChange}
          />
          <button type="submit" className="btn btn-success">
            Sign Up
          </button>
        </div>
      </form>
      <div className="login">
        <p>Already have an Account? </p>
        <Link to="/Login" /*type="submit"*/   className="btn btn-primary">
          Login
        </Link>
      </div>
    </div>
  );
};

export default Signup;